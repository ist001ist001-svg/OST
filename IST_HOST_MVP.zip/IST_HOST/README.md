# IST HOST (초기 MVP)

Render 배포용 Flask 기반 디스코드 봇 관리 패널의 시작 프로젝트입니다.

## 현재 포함된 기능
- Discord OAuth2 로그인
- 사용자별 프로젝트 생성/삭제
- 파일 생성/수정/삭제
- 수정 전 `.bak` 백업
- ZIP 프로젝트 업로드 (경로 탈출 및 크기 제한 검사)
- 공개 GitHub 저장소 ZIP 가져오기
- `main.py` Python 문법 검사
- 모바일 대응 다크 UI

## 아직 연결되지 않은 기능
실제 봇 시작/중지/재시작은 의도적으로 비활성화되어 있습니다. 여러 사용자가 올린 임의 코드를 웹 서버 프로세스에서 직접 실행하면 다른 사용자의 데이터와 서비스 비밀정보가 위험해질 수 있습니다. 실제 실행은 별도의 격리된 실행 환경(Render Sandboxes 등)과 실행 제한, 네트워크 정책, 자원 제한을 붙인 뒤 연결해야 합니다. 현재 시작 버튼은 이 점을 안내합니다.

## Render 배포
1. 이 폴더 전체를 GitHub 저장소에 업로드합니다.
2. Render에서 New > Blueprint를 선택하고 저장소를 연결합니다.
3. Blueprint가 웹 서비스와 PostgreSQL을 만들도록 진행합니다.
4. Render 서비스 환경변수에 아래 값을 입력합니다.
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `DISCORD_REDIRECT_URI` = `https://서비스주소.onrender.com/oauth/callback`
5. Discord Developer Portal의 OAuth2 Redirects에도 같은 callback 주소를 등록합니다.
6. `SECRET_KEY`는 Render에서 생성된 값을 사용합니다.

## 보안/운영 주의
- `SECRET_KEY` 기본값은 배포 전에 반드시 Render의 생성된 Secret으로 대체되어야 합니다.
- 봇 토큰을 소스 코드에 넣지 말고, 실제 실행기 연결 시 암호화된 비밀 저장소를 사용하세요.
- 이 초기 버전은 공개 GitHub 저장소만 가져옵니다.
- 현재 ZIP/GitHub 가져오기는 기존 파일을 덮어쓸 수 있으므로 중요한 파일은 먼저 백업하세요.
- 공개 서비스로 운영하기 전 CSRF 방어, 요청 제한, 감사 로그, 파일별 용량/쿼터, 관리자 권한 정책을 추가해야 합니다.
