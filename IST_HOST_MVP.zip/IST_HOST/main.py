import os, re, io, ast, zipfile, secrets
from pathlib import Path, PurePosixPath
from urllib.parse import urlencode
import requests
from flask import Flask, render_template, redirect, url_for, request, session, flash, abort, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.utils import secure_filename

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = Path(os.getenv("DATA_DIR", BASE_DIR / "data")).resolve()
DATA_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "CHANGE-ME-BEFORE-DEPLOYING")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL", f"sqlite:///{DATA_DIR / 'ist_host.db'}").replace("postgres://", "postgresql://", 1)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["MAX_CONTENT_LENGTH"] = 20 * 1024 * 1024
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.String(80), primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    avatar = db.Column(db.String(300))

class BotProject(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    owner_id = db.Column(db.String(80), db.ForeignKey("user.id"), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    status = db.Column(db.String(30), default="stopped")
    source = db.Column(db.String(20), default="manual")
    created_at = db.Column(db.DateTime, server_default=db.func.now())

def current_user():
    uid = session.get("user_id")
    return db.session.get(User, uid) if uid else None

def login_required():
    if not current_user():
        flash("먼저 Discord 로그인을 해주세요.", "warning")
        return False
    return True

def project_root(project_id):
    # Every project directory is named with its database ID, never a user-supplied path.
    return (DATA_DIR / "projects" / str(project_id)).resolve()

def owned_project(project_id):
    if not login_required():
        return None
    p = db.session.get(BotProject, project_id)
    if not p or p.owner_id != current_user().id:
        abort(404)
    return p

def safe_file(project_id, relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or not rel.parts or any(x in ("", ".", "..") for x in rel.parts):
        abort(400, "잘못된 파일 경로입니다.")
    base = project_root(project_id)
    target = (base / Path(*rel.parts)).resolve()
    if base not in target.parents:
        abort(400, "허용되지 않은 경로입니다.")
    return target

def safe_extract_zip(blob, destination):
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(blob)) as zf:
        entries = zf.infolist()
        if len(entries) > 500:
            raise ValueError("ZIP 파일에는 최대 500개 항목까지 허용됩니다.")
        total = sum(x.file_size for x in entries)
        if total > 50 * 1024 * 1024:
            raise ValueError("압축 해제 크기는 50MB 이하여야 합니다.")
        for item in entries:
            name = item.filename.replace("\\\\", "/")
            path = PurePosixPath(name)
            if path.is_absolute() or any(p in ("..", "") for p in path.parts):
                raise ValueError("ZIP 안에 안전하지 않은 경로가 있습니다.")
            if item.is_dir():
                continue
            target = (destination / Path(*path.parts)).resolve()
            if destination.resolve() not in target.parents:
                raise ValueError("ZIP 경로가 허용 범위를 벗어났습니다.")
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(item) as src, open(target, "wb") as dst:
                dst.write(src.read())

@app.get("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return render_template("login.html")

@app.get("/login")
def login():
    client_id = os.getenv("DISCORD_CLIENT_ID")
    if not client_id:
        flash("Render 환경변수 DISCORD_CLIENT_ID 설정이 필요합니다.", "danger")
        return redirect(url_for("index"))
    state = secrets.token_urlsafe(24)
    session["oauth_state"] = state
    params = {"client_id": client_id, "redirect_uri": os.getenv("DISCORD_REDIRECT_URI", ""),
              "response_type": "code", "scope": "identify", "state": state}
    return redirect("https://discord.com/oauth2/authorize?" + urlencode(params))

@app.get("/oauth/callback")
def oauth_callback():
    if request.args.get("state") != session.pop("oauth_state", None):
        abort(400, "OAuth state 검증에 실패했습니다.")
    code = request.args.get("code")
    token_resp = requests.post("https://discord.com/api/oauth2/token", data={
        "client_id": os.getenv("DISCORD_CLIENT_ID"),
        "client_secret": os.getenv("DISCORD_CLIENT_SECRET"),
        "grant_type": "authorization_code", "code": code,
        "redirect_uri": os.getenv("DISCORD_REDIRECT_URI"),
    }, headers={"Content-Type": "application/x-www-form-urlencoded"}, timeout=15)
    token_resp.raise_for_status()
    access_token = token_resp.json()["access_token"]
    profile = requests.get("https://discord.com/api/users/@me",
                           headers={"Authorization": f"Bearer {access_token}"}, timeout=15)
    profile.raise_for_status()
    data = profile.json()
    user = db.session.get(User, data["id"]) or User(id=data["id"], username=data["username"])
    user.username = data["username"]
    user.avatar = data.get("avatar")
    db.session.add(user); db.session.commit()
    session["user_id"] = user.id
    return redirect(url_for("dashboard"))

@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.get("/dashboard")
def dashboard():
    if not login_required(): return redirect(url_for("index"))
    projects = BotProject.query.filter_by(owner_id=current_user().id).order_by(BotProject.id.desc()).all()
    return render_template("dashboard.html", user=current_user(), projects=projects)

@app.post("/bots/create")
def create_bot():
    if not login_required(): return redirect(url_for("index"))
    name = (request.form.get("name") or "").strip()[:80]
    if not name: flash("봇 이름을 입력해주세요.", "danger"); return redirect(url_for("dashboard"))
    p = BotProject(owner_id=current_user().id, name=name)
    db.session.add(p); db.session.commit()
    (project_root(p.id)).mkdir(parents=True, exist_ok=True)
    (project_root(p.id) / "main.py").write_text("# 여기에 봇 코드를 작성하세요.\\n", encoding="utf-8")
    (project_root(p.id) / "requirements.txt").write_text("discord.py\\n", encoding="utf-8")
    return redirect(url_for("files_page", project_id=p.id))

@app.get("/bots/<int:project_id>/files")
def files_page(project_id):
    p = owned_project(project_id)
    base = project_root(p.id)
    listing = []
    if base.exists():
        for f in sorted(base.rglob("*")):
            if f.is_file():
                listing.append(f.relative_to(base).as_posix())
    return render_template("files.html", project=p, files=listing)

@app.get("/bots/<int:project_id>/file")
def read_file(project_id):
    p = owned_project(project_id)
    rel = request.args.get("path", "")
    target = safe_file(p.id, rel)
    if not target.is_file(): abort(404)
    if target.stat().st_size > 1_000_000: abort(413)
    return render_template("editor.html", project=p, path=rel, content=target.read_text(encoding="utf-8", errors="replace"))

@app.post("/bots/<int:project_id>/file/save")
def save_file(project_id):
    p = owned_project(project_id)
    rel = request.form.get("path", "")
    target = safe_file(p.id, rel)
    content = request.form.get("content", "")
    if len(content.encode("utf-8")) > 1_000_000:
        flash("파일은 1MB 이하만 저장할 수 있습니다.", "danger")
        return redirect(url_for("files_page", project_id=p.id))
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        backup = target.with_name(target.name + ".bak")
        backup.write_bytes(target.read_bytes())
    target.write_text(content, encoding="utf-8")
    flash("저장 완료. 백업 파일도 생성했습니다.", "success")
    return redirect(url_for("read_file", project_id=p.id, path=rel))

@app.post("/bots/<int:project_id>/file/new")
def new_file(project_id):
    p = owned_project(project_id)
    rel = request.form.get("path", "")
    target = safe_file(p.id, rel)
    if target.exists(): flash("이미 존재하는 파일입니다.", "danger")
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text("", encoding="utf-8")
        flash("파일을 만들었습니다.", "success")
    return redirect(url_for("files_page", project_id=p.id))

@app.post("/bots/<int:project_id>/file/delete")
def delete_file(project_id):
    p = owned_project(project_id)
    rel = request.form.get("path", "")
    target = safe_file(p.id, rel)
    if target.is_file():
        target.unlink()
        flash("파일을 삭제했습니다.", "success")
    return redirect(url_for("files_page", project_id=p.id))

@app.post("/bots/<int:project_id>/upload")
def upload_zip(project_id):
    p = owned_project(project_id)
    upload = request.files.get("zipfile")
    if not upload or not upload.filename.lower().endswith(".zip"):
        flash("ZIP 파일을 선택해주세요.", "danger")
        return redirect(url_for("files_page", project_id=p.id))
    try:
        safe_extract_zip(upload.read(), project_root(p.id))
        p.source = "zip"; db.session.commit()
        flash("ZIP 업로드 완료. 파일 목록을 확인해주세요.", "success")
    except Exception as e:
        flash(f"업로드 실패: {e}", "danger")
    return redirect(url_for("files_page", project_id=p.id))

@app.post("/bots/<int:project_id>/github")
def github_import(project_id):
    p = owned_project(project_id)
    url = (request.form.get("repo_url") or "").strip()
    match = re.fullmatch(r"https://github\\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+)", url.rstrip("/"))
    if not match:
        flash("공개 GitHub 저장소 주소를 입력해주세요.", "danger")
        return redirect(url_for("files_page", project_id=p.id))
    owner, repo = match.groups()
    try:
        r = requests.get(f"https://api.github.com/repos/{owner}/{repo}/zipball", timeout=30)
        r.raise_for_status()
        safe_extract_zip(r.content, project_root(p.id))
        p.source = "github"; db.session.commit()
        flash("GitHub 저장소 가져오기 완료.", "success")
    except Exception as e:
        flash(f"가져오기 실패: {e}", "danger")
    return redirect(url_for("files_page", project_id=p.id))

@app.get("/bots/<int:project_id>/check")
def check_project(project_id):
    p = owned_project(project_id)
    base = project_root(p.id)
    results = []
    main = base / "main.py"
    if not main.exists():
        results.append(("error", "main.py 파일이 없습니다."))
    else:
        try:
            ast.parse(main.read_text(encoding="utf-8"))
            results.append(("ok", "main.py Python 문법 검사 통과"))
        except SyntaxError as e:
            results.append(("error", f"main.py {e.lineno}번째 줄: {e.msg}"))
    req = base / "requirements.txt"
    results.append(("ok" if req.exists() else "warning",
                    "requirements.txt 확인" if req.exists() else "requirements.txt가 없습니다."))
    return render_template("check.html", project=p, results=results)

@app.post("/bots/<int:project_id>/action/<action>")
def bot_action(project_id, action):
    p = owned_project(project_id)
    if action not in ("start", "stop", "restart"): abort(404)
    # Intentionally do not execute uploaded code inside the web service.
    # Connect a dedicated isolated Render Sandbox runner before enabling real execution.
    flash("실행 엔진 연결 전입니다. 파일 관리와 코드 검사는 사용할 수 있습니다. 실제 봇 실행은 격리된 Sandbox Worker 연결 후 활성화됩니다.", "warning")
    return redirect(url_for("dashboard"))

@app.post("/bots/<int:project_id>/delete")
def delete_bot(project_id):
    p = owned_project(project_id)
    import shutil
    shutil.rmtree(project_root(p.id), ignore_errors=True)
    db.session.delete(p); db.session.commit()
    flash("프로젝트를 삭제했습니다.", "success")
    return redirect(url_for("dashboard"))

with app.app_context():
    db.create_all()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "10000")))
